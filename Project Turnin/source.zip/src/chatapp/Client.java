/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package chatapp;
import java.io.*;
import java.net.*;

/**
 * Module name: Chat Application's Client
 * File name: Client.java
 *
 * <p>Summary: </p>
 * @author mrtodd
 */
public class Client {
    private final static int START = 0;
    private final static int RECEIVE = 1;
    private final static int DISCONNECT = 3;
    private final static int STANDARDPORT = 1234;

    final static String ENDCHAT = "/log";
    final static String PING = "/ping";
    final static String CHANGESERVER = "/server";


    public static BufferedReader inFromUser;
    private static BufferedReader inFromClient;
    private static Socket mySocket;
    private static ServerSocket serverSocket;
    private static String serverIP = "localhost";
    private static DataOutputStream outToClient;
    private static int port;
    private static boolean amIServer;

    private static String mainServerIP;
    private static int mainServerPort;


    public static void createClient() throws IOException{
        //CONNECT TO MAIN SERVER
        String choice;
        int portInt = STANDARDPORT;
        if(inFromUser == null)
            inFromUser = new BufferedReader( new InputStreamReader(System.in));
        System.out.print("What port: ");
        choice = inFromUser.readLine();
        boolean test = false;
        while(!test){
            try{
                portInt = Integer.parseInt(choice);
                test = true;
            }
            catch (NumberFormatException e){
                System.out.println("That is not a valid port");
                test = false;
            }
        }
        System.out.print("Server Address: ");
        String server = inFromUser.readLine();

        serverIP = server;
        mainServerIP = server;
        mainServerPort = portInt;
        port = portInt;
        amIServer = false; //NOT IMPLMENTED
        chat();
    }

    

    private static void chat(){
        System.out.println("Main Server Running on Port: " + port);
        System.out.println("Client command: " + CHANGESERVER + " <server address> [port]");
        String clientSentence, tempString;
        String message = "";
        int count = 1000000;
        int switchInt = 0;


        Boolean test = true;
        while(test){
            count--;
            switch(switchInt){
                case START:
                try{
                    setupSockets();
                    switchInt = RECEIVE;
                }catch(IOException e) {
                    closeConnections();
                    test = false;
                }
                break;
                case RECEIVE:
                    try{
                        if(count == 0){
                            test = ping();
                            count = 1000000;
                        }
                        else{
                            if(inFromClient.ready()){
                                clientSentence = inFromClient.readLine();
                                if((clientSentence != null) && clientSentence.length() > 0){
                                    if(clientSentence.equals(ENDCHAT)){
                                        switchInt = DISCONNECT;
                                        System.out.println(clientSentence);
                                    }
                                    else if(clientSentence.equals(PING));
                                    else
                                        System.out.println(clientSentence);
                                }
                            }
                            if(inFromUser.ready()){
                                message = inFromUser.readLine();

                                if((message != null) && message.length() > 0){
                                    if(message.equals(ENDCHAT)){
                                        switchInt = DISCONNECT;
                                        outToClient.writeBytes(message + '\n');
                                    }
                                    else if(message.startsWith(CHANGESERVER)){
                                        String[] split = message.split(" ");
                                        if(split.length == 3){
                                            try{
                                                mainServerPort = Integer.parseInt(split[2]);
                                                mainServerIP = split[1];
                                                switchInt = DISCONNECT;
                                            }
                                            catch (NumberFormatException e){
                                                System.out.println("Try: " + CHANGESERVER + " <server> [port]");
                                            }
                                        }
                                        else if(split.length == 2){
                                            mainServerIP = split[1];
                                            switchInt = DISCONNECT;
                                        }
                                        else
                                            System.out.println("Try: " + CHANGESERVER + " <server> [port]");
                                    }
                                    else
                                        outToClient.writeBytes(message + '\n');
                                }
                            }
                        }
                    }
                    catch (IOException e){
                        closeConnections();
                        test = false;
                    }
                break;
                case DISCONNECT:
                    closeConnections();
                    //test = false;
                    if(serverIP.equals(mainServerIP) && mainServerPort == port)
                        test = false;
                    else{
                        serverIP = mainServerIP;
                        port = mainServerPort;
                        switchInt = START;
                        amIServer = false;
                    }
                break;

            }
        }

    }

    private static void setupSockets() throws IOException{
        if(amIServer){
            serverSocket = new ServerSocket(port);
            mySocket = serverSocket.accept();
            System.out.print("Client has connected!\n");
        }
        else
            mySocket = new Socket(serverIP, port);
        if(inFromClient == null)
            inFromClient =
                new BufferedReader(new InputStreamReader(mySocket.getInputStream()));
        outToClient = new DataOutputStream(mySocket.getOutputStream());
        
    }
        private static void closeConnections() {
        try{
            if(serverSocket != null){
                serverSocket.close();
                serverSocket = null;
            }
        }
        catch (IOException e){
            serverSocket = null;
        }
        try{
            if(mySocket != null){
                mySocket.close();
                mySocket = null;
            }
        }
        catch(IOException e){
            mySocket = null;
        }
        try{
            if(inFromClient != null){
                inFromClient.close();
                inFromClient = null;
            }
        }
        catch(IOException e){
            inFromClient = null;
        }
        /*try{
            if(inFromUser != null){
                inFromUser.close();
                inFromUser = null;
            }
        }
        catch(IOException e){
            inFromUser = null;
        }*/
        try{
            if(outToClient != null){
                outToClient.close();
                outToClient = null;
            }
        }
        catch(IOException E){
            outToClient = null;
        }
        System.out.println("Chat has ended.");

    }
        private static boolean ping(){
            boolean ret = true;
            try{
                outToClient.writeBytes(PING + '\n');
            }
            catch(IOException e){
                closeConnections();
                ret = false;
            }
            return ret;
        }
}

