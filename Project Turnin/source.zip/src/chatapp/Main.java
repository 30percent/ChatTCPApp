/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package chatapp;
import java.io.*;

/**
 *
 * @author mrtodd
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    public static final int STANDARDPORT = 1234;
    public static final String STANDARDNAME = "localhost";
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        System.out.print("Client or Server: ");
        BufferedReader input;
        String choice;
        boolean test = false;
        int port =STANDARDPORT;
        String serverName = STANDARDNAME;
        Client.inFromUser = new BufferedReader( new InputStreamReader(System.in));
        choice = Client.inFromUser.readLine();
        if(choice.equalsIgnoreCase("server")){
            System.out.print("What port: ");
            choice = Client.inFromUser.readLine();
            while(!test){
                try{
                    port = Integer.parseInt(choice);
                    test = true;
                }
                catch (NumberFormatException e){
                    System.out.println("That is not a valid port");
                    test = false;
                }
            }
            choice = "";
            System.out.print("Name of Server: ");
            while(choice.length() < 1){
                choice = Client.inFromUser.readLine();
            }
            serverName = choice;
            MainServer serv = new MainServer(port, serverName);
        }
        else if(choice.equalsIgnoreCase("client")){
            try{
                Client.createClient();
            }
            catch (IOException e){
                System.out.println("Error in reading from input.");
                System.exit(1);
            }
        }
    }

}
